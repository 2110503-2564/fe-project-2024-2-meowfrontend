import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { BookingItem } from "../../../interface";

type BookState = {
  bookItems: BookingItem[];
};

const initialState: BookState = { bookItems: [] };

export const bookSlice = createSlice({
  name: "booking",
  initialState,
  reducers: {
    addBooking: (state, action: PayloadAction<BookingItem>) => {
      // ตรวจสอบการจองสถานที่เดียวกันและวันเดียวกัน
      const existingBookingIndex = state.bookItems.findIndex(
        (item) =>
          item.venue === action.payload.venue && item.bookDate === action.payload.bookDate
      );

      if (existingBookingIndex !== -1) {
        // ถ้ามีการจองในสถานที่เดียวกันและวันเดียวกัน ให้แทนที่ข้อมูลเดิม
        state.bookItems[existingBookingIndex] = action.payload;
      } else {
        // ตรวจสอบว่ามีการจองเกิน 3 ครั้งหรือไม่
        if (state.bookItems.length >= 3) {
        alert("คุณไม่สามารถจองได้มากกว่า 3 ครั้ง");
        return; // หยุดการทำงาน ไม่เพิ่มข้อมูลใหม่
      }
        // ถ้าไม่พบ ให้เพิ่มข้อมูลการจองใหม่
        state.bookItems.push(action.payload);
      }
    },
    removeBooking: (state, action: PayloadAction<BookingItem>) => {
      // ลบการจองโดยใช้ข้อมูลชื่อ, เบอร์โทร, สถานที่ และวัน
      state.bookItems = state.bookItems.filter(
        (item) =>
          !(item.nameLastname === action.payload.nameLastname &&
            item.tel === action.payload.tel &&
            item.venue === action.payload.venue &&
            item.bookDate === action.payload.bookDate)
      );
    },
    clearBookings: (state) => {
      // เคลียร์รายการการจองทั้งหมด
      state.bookItems = [];
    },
  },
});

export const { addBooking, removeBooking, clearBookings } = bookSlice.actions;
export default bookSlice.reducer;
