import BookingList from "@/components/BookingList";

export default function MyBookingPage() {
    return (
        <div>
            <BookingList/>
        </div>
    );
}