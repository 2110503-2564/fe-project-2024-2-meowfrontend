'use client';

import DateReserve from "@/components/DateReserve";
import * as React from 'react';
import Box from '@mui/material/Box';
import TextField from '@mui/material/TextField';
import { addBooking } from "@/redux/features/bookSlice";
import { useDispatch } from "react-redux";
import { AppDispatch } from "@/redux/store";
import Button from "@mui/material/Button";
import MenuItem from '@mui/material/MenuItem';
import Select from '@mui/material/Select';

export default function Bookings() {
    const dispatch = useDispatch<AppDispatch>();
    const [nameLastname, setNameLastname] = React.useState("");
    const [tel, setTel] = React.useState("");
    const [venue, setVenue] = React.useState("");
    const [bookDate, setBookDate] = React.useState("");
    const [startTime, setStartTime] = React.useState("");  // สถานะสำหรับเวลาเริ่มต้น
    const [endTime, setEndTime] = React.useState("");      // สถานะสำหรับเวลาสิ้นสุด

    const makeBooking = () => {
        if (nameLastname && tel && venue && bookDate && startTime && endTime) {
            const item = {
                nameLastname,
                tel,
                venue,
                bookDate,
                startTime,
                endTime
            };
            console.log("Booking Item to Dispatch: ", item);  // Log the item
            dispatch(addBooking(item)); // Dispatch action to Redux
        } else {
            console.log("Incomplete booking details:", { nameLastname, tel, venue, bookDate, startTime, endTime });
        }
    };
    
    return (
        <main className="bg-slate-100 m-5 p-5">
            {/* ส่วนของการจองสถานที่ */}
            <main className="w-[100%] flex flex-col items-center space-y-4">
                <div className="text-xl font-medium">New Booking</div>

                <div className="w-fit space-y-2">
                    <div className="text-md text-left text-gray-600">Date Reserve</div>
                    <DateReserve onChange={setBookDate} />
                </div>

                <Box component="form" sx={{ '& > :not(style)': { m: 1, width: '25ch' } }} noValidate autoComplete="off">
                    <TextField
                        id="name-lastname"
                        label="Name-Lastname"
                        variant="standard"
                        name="Name-Lastname"
                        value={nameLastname}
                        onChange={(e) => setNameLastname(e.target.value)}
                    />
                    <TextField
                        id="contact-number"
                        label="Contact-Number"
                        variant="standard"
                        name="Contact-Number"
                        value={tel}
                        onChange={(e) => setTel(e.target.value)}
                    />
                    <Select
                        id="venue"
                        value={venue}
                        onChange={(e) => setVenue(e.target.value)}
                        displayEmpty
                        fullWidth
                        variant="standard"
                    >
                        <MenuItem value="Bloom">Japanese Massage</MenuItem>
                        <MenuItem value="Spark">Salt Spa and Massage</MenuItem>
                        <MenuItem value="GrandTable">Massage Therapy</MenuItem>
                        <MenuItem value="GrandTable">Grotta Thermal Spa</MenuItem>
                        <MenuItem value="GrandTable">Bandwidth</MenuItem>
                        <MenuItem value="Bloom">Himalayan Salt Massage</MenuItem>
                        <MenuItem value="Spark">Relaxing</MenuItem>
                        <MenuItem value="GrandTable">Portals</MenuItem>
                        <MenuItem value="GrandTable">Solutions</MenuItem>
                        <MenuItem value="GrandTable">Communities</MenuItem>
                    </Select>

                     {/* ฟิลด์สำหรับเวลาเริ่มต้นและสิ้นสุด */}
                     <TextField
                        id="start-time"
                        label="Start Time"
                        type="time"
                        variant="standard"
                        value={startTime}
                        onChange={(e) => setStartTime(e.target.value)}
                        InputLabelProps={{
                            shrink: true,
                        }}
                        inputProps={{
                            step: 300, // 5 minutes increment
                        }}
                    />
                    <TextField
                        id="end-time"
                        label="End Time"
                        type="time"
                        variant="standard"
                        value={endTime}
                        onChange={(e) => setEndTime(e.target.value)}
                        InputLabelProps={{
                            shrink: true,
                        }}
                        inputProps={{
                            step: 300, // 5 minutes increment
                        }}
                    />
                    
                </Box>

                <Button
                    variant="contained"
                    color="primary"
                    onClick={makeBooking} 
                >
                    Book Venue
                </Button>
            </main>
        </main>
    );
}
