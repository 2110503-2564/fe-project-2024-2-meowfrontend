export default function Booking () {
    return (
        <main className="pt-16">
            <div className="text-blue-100">Venue Booking</div>
        </main>
    );
}
